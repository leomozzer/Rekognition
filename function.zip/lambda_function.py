import json
#boto3 para integrações
import boto3
rekognition=boto3.client('rekognition')

#DynamoDB
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
dynamodb = boto3.resource("dynamodb", region_name='us-east-1')
table = dynamodb.Table('Face') #Nome da tabela do DynamoDB que será usada para salvar FaceID's e o nome dos usuários do slack

#usado para dar um POST na url do Slack
import requests

#Variáveis
bucket = '' #nome do bucket criado na s3
collectionId = "" #Nome da coleção criada
slack_token = '' #token do slack depois de ter criado o app
slack_channel = '' # canal que será enviada a mensagem quando a função for acionada


def lambda_handler(event, context): #Verifica se houve alguma modificação no bucket
    print("Iniciado")
    #print(event)
    #print(context)
    imagePath = event['Records'][0]['s3']['object']['key'] #vai coletar o nome do arquivo que foi adicionado ao bucket
    path = imagePath.split('/')
    s3BucketObject = {#cria um objeto que contém o nome do bucket e o nome do arquivo que foi criado
        'S3Object':{'Bucket':bucket, 'Name':imagePath}
    }
    print(path)
    print(s3BucketObject)
    return createTable() #Comentar depois do primeiro evento
    # procura por faces na imagem que está salva no bucket (usa a variável s3BucketObject)
    response=rekognition.search_faces_by_image(CollectionId=collectionId, Image=s3BucketObject, FaceMatchThreshold=70, MaxFaces=2)
    print(response)
    print(len(response['FaceMatches']))
    #verifica o tamanho do FaceMatches
    if len(response['FaceMatches']) > 1:
        #Vai verificar se a FaceMatches com maior confiança é a primeira
        faceConfidence = response['FaceMatches'][0]['Similarity']
        faceID = response['FaceMatches'][0]['Face']['FaceId']
        print("len(response['FaceMatches']) maior do que 1")
        for x in range(len(response['FaceMatches'])):
            print(faceConfidence)
            print(faceID)
            if faceConfidence < response['FaceMatches'][x]['Similarity']:
                faceConfidence = response['FaceMatches'][x]['Similarity']
                faceID = response['FaceMatches'][x]['Face']['FaceId']
        #Ao fim do for loop irá executar a seguinte função
        return checkDynamoDB(faceID, imagePath)
    elif len(response['FaceMatches']) == 1: #Se reconhecer somente uma face depois da consulta será feita a consulta no banco de dados
        faceID = response['FaceMatches'][0]['Face']['FaceId']
        print("len(response['FaceMatches']) igual a 1")
        #coletar o nome do usuário do slack
        return checkDynamoDB(faceID, imagePath)
    else:
        print("This face i dont know")
        return addFacesToCollection(imagePath, s3BucketObject) #adiciona o rosto não identificado na coleção
        
def checkDynamoDB(faceId, path):
    print('Entrou no checkDynamoDB')
    try:
        print('Consulta sendo realizada')
        print(faceId)
        consultaDynamo = table.query(KeyConditionExpression=Key('faceID').eq(faceId))
        #Consulta do DynamoDB usando a FaceID coletada
        print(consultaDynamo)
        print('This user is: ', consultaDynamo['Items'][0]['Name'])
        #Executa a função que notifica no canal específicado
        return slackNotification('', consultaDynamo['Items'][0]['Name'], path)
    except ClientError as e: #Trata o erro
        print(e.response['Error']['Message'])
        return slackNotification('error', e.response['Error']['Message'], path)
        
            
def addFacesToCollection(key, image):
    '''Função que adiciona images a collection Faces'''
    print(key)
    print(image)
    #Adiciona uma nova imagem na collection Faces
    newFace = rekognition.index_faces(CollectionId=collectionId, Image=image, MaxFaces=1)
    print(newFace)
    rmRegistred = key.split('/')
    rmJpg = rmRegistred[1].split('.')
    #Adiciona ao DynamoDB um novo item contendo a FaceID gerada e 
    #tambem o nome do usário que foi coletado no nome da foto
    newTableItem = table.put_item(Item={'faceID':newFace['FaceRecords'][0]['Face']['FaceId'], 'Name': rmJpg[0]})
    print(newTableItem)
    return slackNotification("New User", rmJpg[0], image)
    
def slackNotification(message, userID, key):
    data = {
        "token": slack_token,
        "user": userID
    }
    text = '';
    print(data)
    if message == "New User":
        text = 'O usuário %s foi adicionado com sucesso' % userID
    elif message == "erro":
        text = userID
    else:
        text = 'Welcome @%s' % userID
    slackJson = {
            'channel': slack_channel,
            'text': text,
            "icon_emoji": ":robot_face:",
            "attachments": [
                {
                    "image_url": "https://s3.amazonaws.com/%s/%s" % (bucket, key),
                    "fallback": "Nope?",
                    "attachment_type": "default",
                }
            ]
        }
    resp = requests.post("https://slack.com/api/chat.postMessage", headers={'Content-Type':'application/json;charset=UTF-8', 'Authorization': 'Bearer %s' % slack_token}, json=slackJson)
    print(resp)
    return {}
    
def createTable(): #Cria uma nova tabela no DynamoDB
    newTable = dynamodb.create_table(
        TableName='Face',
        KeySchema=[
            {
                'AttributeName': 'faceID',
                'KeyType': 'HASH'
            },
            {
                'AttributeName': 'Name',
                'KeyType': 'HASH'
            }
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'faceID',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'Name',
                'AttributeType': 'S'
            }
    
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 10,
            'WriteCapacityUnits': 10
        }
    )

    print("Table status:", newTable.table_status)
    
